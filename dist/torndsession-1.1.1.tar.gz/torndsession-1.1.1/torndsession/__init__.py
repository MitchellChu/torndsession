#!/usr/bin/env python
# -*- coding:utf-8 -*-

# Copyright 2014 Mitchell Chu

"""This is a Tornado Session Extension """

from __future__ import absolute_import, division, print_function, with_statement

version = "1.1.1"
vrsion_info = (1, 1, 1, 0)
